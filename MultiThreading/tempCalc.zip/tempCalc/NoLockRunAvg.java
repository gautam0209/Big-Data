import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

// Class with 5 threads and no locks

public class NoLockRunAvg implements Runnable
{
	private List<String> list;
	private static Map<String,List<Double>> map ; // store the <stationId, list<count,sumofTemp,average>>
	
	public NoLockRunAvg(List<String> l)
	{
		list = l;
	}
	
	public void initializeMap()
	{
		map = new HashMap<>();
	}
	
	// run method for Thread
	public void run()
	{
		computeAccumulatedTemp();
	}
	

	//It will compute the accumulated temperature for each station id
	public void computeAccumulatedTemp()
	{	
		Iterator<String> itr = list.iterator();	
		String[] line ;
		while(itr.hasNext())
		{
			String l = itr.next();
			line = l.split(",");
			storeSumCountValue(line);
		}		
	}
	
	// It will update the sum and count for temprature for station id in line[]
	public void storeSumCountValue(String[] line)
	{
		if(line[2].equals("TMAX"))
		{
			List<Double> listCountSum = map.get(line[0]);
			
			
			if(listCountSum == null){
				listCountSum = new ArrayList<Double>();
				listCountSum.add(0,1d);
				listCountSum.add(1,Double.parseDouble(line[3]));
				listCountSum.add(2,Double.parseDouble(line[3]));}
			else
			{		
				listCountSum.set(0,listCountSum.get(0) +1); // count
				listCountSum.set(1,listCountSum.get(1) + Double.parseDouble(line[3])); // sum
				listCountSum.set(2,((listCountSum.get(2) * (listCountSum.get(0)-1)) + Double.parseDouble(line[3]))/
									listCountSum.get(0)); //running average
			}
			map.put(line[0],listCountSum);
		}
	}
	
	//getter function
	public Map<String, List<Double>> getMap()
	{
		return map;
	}
	
	// It will print the average temperature
	public static void printAverageTemp()
	{
		Iterator<String> itr = map.keySet().iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			List<Double> l = map.get(key);
			System.out.println("StationId: " + key + "|| Average Temp.:" + l.get(2) );
		}	
	}
}