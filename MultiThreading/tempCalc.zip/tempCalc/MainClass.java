import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;


// Class to call all the sequential and multithreaded programs

public class MainClass
{
	Map<String, List<Double>> seqMap ; // Map will store station id as String 
									// and List<Double> will store count, sum and average of temp
									
	//function to compute minimum
	public static long minimum(long[] a)
	{
		long min = a[0];
		for(int i=1; i<a.length; i++)
		{
			if(a[i] < min)
				min = a[i];
		}
		return min;
	}
	
	//function to compute maximum
	public static long maximum(long[] a)
	{
		long max = a[0];
		for(int i=1; i<a.length; i++)
		{
			if(a[i] > max)
				max = a[i];
		}
		return max;
	}
	
	// reduce list of hash maps into one given in second parameter
	public static void reduceHashMaps(List <NoSharingRunAvg> objs, NoSharingRunAvg baseMap)
	{
		Iterator<NoSharingRunAvg> itr = objs.iterator();	
		while(itr.hasNext())
		{
			reduceTwoHashMaps(itr.next(),baseMap);
		}
	}
	
	// merge hashmap of first object into second's object hashmap
	public static void reduceTwoHashMaps(NoSharingRunAvg obj,NoSharingRunAvg baseMap)
	{
		Map<String,List<Double>> temp = obj.getHashMap(); // iterator over input map
		Map<String,List<Double>> map = baseMap.getHashMap(); // iterator for map in which we will merge
		Iterator<String> itrTemp = temp.keySet().iterator();
		List<Double> tempList= new ArrayList<Double>();
		List<Double> thisList= new ArrayList<Double>();
		while(itrTemp.hasNext())
		{
			String key = itrTemp.next();
			tempList = temp.get(key);
			thisList = map.get(key);
			if(thisList == null)
				map.put(key,tempList);
			else
			{
				tempList.set(0,tempList.get(0) + thisList.get(0));
				tempList.set(1,tempList.get(1) + thisList.get(1));
				tempList.set(2,tempList.get(1)/tempList.get(0));
				map.put(key,tempList);
			}
		}	
	}
	
	//function to compute average
	
	public static double average(long[] a)
	{
		long s=0;
		for(int i=0; i<a.length; i++)
		{
			s += a[i];
		}
		return (double)s/a.length;
	}
	
	
	// function to compare data in final map with the calling object's map(Sequential Run)
	public int compareData(Map<String, List<Double> > m)
	{
		Iterator<String> itr = seqMap.keySet().iterator();
		int counter =0;
		while(itr.hasNext())
		{
			String key = itr.next();
			List<Double> seqL = seqMap.get(key);
			List<Double> l = m.get(key);

			if(l == null) // if key is not present in input map
			{
				counter++;
			}
			else
			{	
				 if(!(seqL.get(0).equals(l.get(0)))) // if average of i/p map is not equal to sequential map
					counter++;
			}
		}	
	return counter;
	}
	
	
	//this is the function to execute the runs
	public void execute(List<String> l)
	{
		int size = l.size();
		long startTime;
		Thread t1,t2,t3,t4,t5;
		int s1 = size/5;
		int s2 = 2*size/5;
		int s3 = 3*size/5;
		int s4 = 4*size/5;
		int i =0;
		long a[] = new long[10]; // array to store time
		double seqAvgTime = 0;
		
		
		// Sequential Run//
		SequentialRunAvg sra = new SequentialRunAvg(l);
		
		for(i =0; i<10 ;i++)
		{ 
			sra.initializeMap();
			startTime = System.currentTimeMillis();
			sra.computeAccumulatedTemp();
			a[i] = System.currentTimeMillis() - startTime;
		}
		
		seqAvgTime = average(a);
		System.out.println("****Sequential Run****");
		System.out.println("Minimum Time for Sequential Run:" + minimum(a));
		System.out.println("Maximum Time for Sequential Run:" + maximum(a));
		System.out.println("Average Time for Sequential Run:" + seqAvgTime);
		
		
		
		
		// NoLockRun//
		

		NoLockRunAvg nlra = new NoLockRunAvg(l.subList(0,s1));
		
		for(i=0;i<10;i++)
		{
			//threads created and assigned the equal part of list
			nlra.initializeMap();
			t1 = new Thread(nlra, "t1");
			t2 = new Thread(new NoLockRunAvg(l.subList(s1,s2 )), "t2");
			t3 = new Thread(new NoLockRunAvg(l.subList(s2,s3)), "t3");
			t4 = new Thread(new NoLockRunAvg(l.subList(s3,s4)), "t4");
			t5 = new Thread(new NoLockRunAvg(l.subList(s4,size)), "t5");

			startTime = System.currentTimeMillis();

			t1.start();
			t2.start();
			t3.start();
			t4.start();
			t5.start();
		
			try{
			
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
			
			}
		catch(InterruptedException e){
				e.printStackTrace();
		}

			a[i] = System.currentTimeMillis() - startTime;
		}
		System.out.println("*******************");
		System.out.println("****No Lock Run****");
		System.out.println("Minimum Time for NoLock Run:" + minimum(a));
		System.out.println("Maximum Time for NoLock Run:" + maximum(a));
		System.out.println("Average Time for NoLock Run:" + average(a));
	
		
		// CoarseLockRun

		CoarseLockRunAvg clra = new CoarseLockRunAvg(l.subList(0,s1)); 
		for(i=0;i<10;i++)
		{
			clra.initializeMap(); //to empty the map for next run
				//threads created and assigned the equal part of list
			t1 = new Thread(clra, "t1");
			t2 = new Thread(new CoarseLockRunAvg(l.subList(s1,s2 )), "t2");
			t3 = new Thread(new CoarseLockRunAvg(l.subList(s2,s3)), "t3");
			t4 = new Thread(new CoarseLockRunAvg(l.subList(s3,s4)), "t4");
			t5 = new Thread(new CoarseLockRunAvg(l.subList(s4,size)), "t5");
			startTime = System.currentTimeMillis();

			t1.start();
			t2.start();
			t3.start();
			t4.start();
			t5.start();
		
			try{
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
			
			}
		catch(InterruptedException e){
				e.printStackTrace();
		}
		a[i] = System.currentTimeMillis() - startTime;
		
	}
		System.out.println("*******************");
		System.out.println("****Coarse Lock Run****");
		System.out.println("Minimum Time for CoarseLock Run:" + minimum(a));
		System.out.println("Maximum Time for CoarseLock Run:" + maximum(a));
		System.out.println("Average Time for CoarseLock Run:" + average(a));

		
		

		// FineLockRunAvg //
		FineLockRunAvg flra = new FineLockRunAvg(l.subList(0,s1));
		for(i=0; i<10; i++)
		{
			flra.initializeMap();
		
			//threads created and assigned the equal part of list
			t1 = new Thread(flra, "t1");
			t2 = new Thread(new FineLockRunAvg(l.subList(s1,s2 )), "t2");
			t3 = new Thread(new FineLockRunAvg(l.subList(s2,s3)), "t3");
			t4 = new Thread(new FineLockRunAvg(l.subList(s3,s4)), "t4");
			t5 = new Thread(new FineLockRunAvg(l.subList(s4,size)), "t5");
			startTime = System.currentTimeMillis();

			t1.start();
			t2.start();
			t3.start();
			t4.start();
			t5.start();
		
			try{
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
			}
		catch(InterruptedException e){
				e.printStackTrace();
		}

			a[i] = System.currentTimeMillis() - startTime;
	}
	
		System.out.println("*******************");
		System.out.println("****Fine Lock Run****");
		System.out.println("Minimum Time for FineLock Run:" + minimum(a));
		System.out.println("Maximum Time for FineLock Run:" + maximum(a));
		System.out.println("Average Time for FineLock Run:" + average(a));
		
		
		// NoSharing//
		
		NoSharingRunAvg ins1,ins2,ins3,ins4,ins5;
		ins1  = new NoSharingRunAvg(l.subList(0,s1));
		
		for(i =0; i<10; i++)
		{
			List<NoSharingRunAvg> list = new ArrayList<NoSharingRunAvg>(); //list to store all the object references
			ins1 = new NoSharingRunAvg(l.subList(0,s1));
			ins2 = new NoSharingRunAvg(l.subList(s1,s2 ));
			ins3 = new NoSharingRunAvg(l.subList(s2,s3));
			ins4 = new NoSharingRunAvg(l.subList(s3,s4));
			ins5 = new NoSharingRunAvg(l.subList(s4,size));

				//threads created and assigned the equal part of list
			t1 = new Thread(ins1, "t1");
			t2 = new Thread(ins2, "t2");
			t3 = new Thread(ins3, "t3");
			t4 = new Thread(ins4, "t4");
			t5 = new Thread(ins5, "t5");

			startTime = System.currentTimeMillis();

			t1.start();
			t2.start();
			t3.start();
			t4.start();
			t5.start();
		
			try{
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
			}
		catch(InterruptedException e){
				e.printStackTrace();
		}
		// adding objects on list
		list.add(ins2);
		list.add(ins3);
		list.add(ins4);
		list.add(ins5);
		MainClass.reduceHashMaps(list,ins1); // calling reducer function
		a[i] = System.currentTimeMillis() - startTime;
	}
	
		System.out.println("*******************");
		System.out.println("****No Sharing Run****");
		
		System.out.println("Minimum Time for NoSharing Run:" + minimum(a));
		System.out.println("Maximum Time for NoSharing Run:" + maximum(a));
		System.out.println("Average Time for NoSharing Run:" + average(a));

		
	}
	
	public static void main(String ar[])
	{
		RoutineLoader rl = new RoutineLoader();
		List<String> l = rl.loader(ar[0]); // to load data to List
		
		System.out.println("Runs without Fibonnacci: ");
		new MainClass().execute(l);
	}
}