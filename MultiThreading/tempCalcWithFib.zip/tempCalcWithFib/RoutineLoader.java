import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.io.*;

/* This class is the routine loader class to loader
data from input file and return the list using loader method.*/
   
public class RoutineLoader
{
	// this will return the content of the files as List<String>
	public List<String> loader(String filename)
	{
		String line;
		List<String> l = new ArrayList<String>();
		
		try
		{
			// this is to load the gzip file in input parameter
			GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(filename));
			Scanner scan = new Scanner(gzis);
			while(scan.hasNext())
			{
				line = scan.next();
				l.add(line);
			}
			scan.close();
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
		return l;
	}
	
}