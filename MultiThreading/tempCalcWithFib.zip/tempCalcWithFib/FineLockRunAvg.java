import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;


// Synchronizing on String key instead of data structure

public class FineLockRunAvg implements Runnable
{
	private List<String> list;
	
	//ConcurrentHashMap Collection put lock on particular key
	private static Map<String,List<Double>> map = new ConcurrentHashMap<>();
	
	public FineLockRunAvg(List<String> l)
	{
		list = l;
	}
	
	public void initializeMap()
	{
		map = new ConcurrentHashMap<>();
	}
	
	// run method for Thread
	public void run()
	{
		computeAccumulatedTemp();
	}
	

	//It will compute the accumulated temperature for each station id
	public void computeAccumulatedTemp()
	{	
		Iterator<String> itr = list.iterator();	
		String[] line ;
		while(itr.hasNext())
		{
			String l = itr.next();
			line = l.split(",");	
			storeSumCountValue(line);
		}		
	}
	
	// It will update the sum and count for temprature for station id in line[]
	public void storeSumCountValue(String[] line)
	{
		if(line[2].equals("TMAX"))
		{
	    List<Double> initiatorList= new ArrayList<Double>(); // initiatorList for new element in map
		initiatorList.add(0,1D);
		initiatorList.add(1,Double.parseDouble(line[3]));
		initiatorList.add(2,Double.parseDouble(line[3]));
		synchronized(line[0])
		{
		initiatorList = map.putIfAbsent(line[0],initiatorList);
		if(initiatorList != null)
		{
				initiatorList.set(0,initiatorList.get(0) + 1);
				initiatorList.set(1,initiatorList.get(1) + Double.parseDouble(line[3]));
				initiatorList.set(2,((initiatorList.get(2) * (initiatorList.get(0)-1)) + Double.parseDouble(line[3]))/
									initiatorList.get(0));
				map.put(line[0],initiatorList);
				Fibonnacci.fib(17); // Calling Fibonnacci
				
		}
	}
}
}

	//getter function
	public Map<String,List<Double>> getMap()
	{
		return map;
	}

	
	// It will print the average temperature
	public static void printAverageTemp()
	{
		Iterator<String> itr = map.keySet().iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			List<Double> l = map.get(key);
			System.out.println("StationId: " + key + "|| Average Temp.:" + l.get(2) );
		}	
	}
}