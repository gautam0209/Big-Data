Steps to execute file -

1. Unzip the tempCalc.zip and tempCalcWithFib.zip file.
2. Go to the path /tempCalc
3. Store your input tar file in /tempCalc path with the source files.
3. From CMD, run javac *.java to compile all the files.
4. Run java MainClass 1912.csv.gz (for example)
5. Repeat same steps for /tempCalcWithFib

-tempCalc.zip contains source files for java to execute 5 program version for multithreading.
-tempCalcWithZip.zip contains source files for java to execute 5 program version for multithreading including 
fibonnacci call.